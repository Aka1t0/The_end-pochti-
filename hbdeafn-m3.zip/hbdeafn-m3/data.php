<?php
/*$con = mysqli_connect("localhost", "root", )*/


date_default_timezone_set('Asia/Yekaterinburg');

$promos = ['Доски и лыжи', 'Крепления', 'Ботинки', 'Одежда', 'Инструменты', 'Разное'];

$lots = [
    ['title' => '2014  Rossignol District Snowboard', 'categories' => $promos[0], 'price' => 10999, 'photo' => 'img/lot-1.jpg', 'timer' => '2023-09-14'],
    ['title' => 'DC Ply Mens 2016/2017 Snowboard', 'categories' => $promos[0], 'price' => 159999, 'photo' => 'img/lot-2.jpg', 'timer' => '2023-09-13 10:20'],
    ['title' => 'Крепления Union Contact Pro 2015 года размер L/XL', 'categories' => $promos[1], 'price' => 8000, 'photo' => 'img/lot-3.jpg', 'timer' => '2023-09-16'],
    ['title' => 'Ботинки для сноуборда DC Mutiny Charocal', 'categories' => $promos[2], 'price' => 10999, 'photo' => 'img/lot-4.jpg', 'timer' => '2023-09-16'],
    ['title' => 'Куртка для сноуборда DC Mutiny Charocal', 'categories' => $promos[3], 'price' => 7500, 'photo' => 'img/lot-5.jpg', 'timer' => '2023-09-25'],
    ['title' => 'Маска Oakley Canopy', 'categories' => $promos[5], 'price' => 5400, 'photo' => 'img/lot-6.jpg', 'timer' => '2023-09-30'],
];
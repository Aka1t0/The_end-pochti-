<?php
require_once('init.php');
require_once('helpers.php');
require_once('functions.php');
$promos = get_categories_for_range($con);
$nav = include_template("nav.php", [
    "promos" => $promos,
]);

if (isset($_SESSION['username'])) {
    header('location: /index.php');
    exit;
} else {
    $errors = [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $required_fields = [
            'email' => 'Введите email',
            'password' => 'Введите пароль'
        ];

        foreach($required_fields as $key => $value) {
            if (empty($_POST[$key])) {
                $errors[$key] = $value;
            }
        }

        if (!isset($errors['email'])) {
            $errors = validateEmail($errors);
        }

        if (!isset($errors['email']) && !isset($errors['password'])) {
            $user = get_user_by_email($con, $_POST['email']);

            if (empty($user) || !password_verify($_POST['password'], $user['password'])) {
                $errors['password'] = 'Неправильный пароль';
            }

            $errors = array_filter($errors);

            if (!$errors) {
                session_start();
                $_SESSION['username'] = $user['name'];
                $_SESSION['user_id'] = $user['id'];
                print ($_SESSION['username']);
                header('Location: ../index.php');
                exit;
            }
        }
    }

    $login = include_template('login.php', [
        'promos' => $promos,
        'nav' => $nav,
        'errors' => $errors,  
    ]);

    $layout = include_template('layout.php', [
        'title' => 'Авторизация',
        "content" => $login,
        "promos" => $promos,
        "nav" => $nav,
    ]);

    print($layout);
}
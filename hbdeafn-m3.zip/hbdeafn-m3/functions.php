<?php
const HOURS_IN_DAY = 24;
const SECOND_IN_HOURS = 3600;
const SECOND_IN_MINUTES = 60;
const IMAGE_EXTENSIONS = ['jpg', 'png', 'webp', 'gif'];
date_default_timezone_set( 'Asia/Yekaterinburg');

function format(int $price):string {
     return number_format($price, 0, '.', ' ').' ₽';
}

function formatDate(string $date): string {
    $passedTime = time() - strtotime($date);

    $days = round($passedTime / (HOURS_IN_DAY * SECOND_IN_HOURS));
    if ($days > 0) {
        return $days . ' ' . get_noun_plural_form($days, 'день', 'дня', 'дней');
    }

    $hours = round($passedTime / SECOND_IN_HOURS);
    if ($hours > 0) {
        return $hours . ' ' . get_noun_plural_form($hours, 'час', 'часа', 'часов');
    }

    $minutes = round($passedTime / SECOND_IN_MINUTES);
    if ($minutes > 0) {
        return $minutes . ' ' . get_noun_plural_form($minutes, 'минуту', 'минуты', 'минут');
    }

    $seconds = round($passedTime);
    return $seconds . ' ' . get_noun_plural_form($seconds, 'секунду', 'секунды', 'секунд');
}

function get_dt_range(string $timer):array{
    $time = strtotime($timer . '+1 day') - time() + SECOND_IN_MINUTES;

    $hours = str_pad(floor($time /SECOND_IN_HOURS ), 2, "0", STR_PAD_LEFT);
    $minutes = str_pad(floor(($time / SECOND_IN_MINUTES) %  SECOND_IN_MINUTES ), 2, "0", STR_PAD_LEFT);

    return [$hours, $minutes];
}
function get_user_for_range(mysqli $con): array
{
    $sql = "SELECT id, date_registration, email, name, password, contact password FROM User";
    return mysqli_fetch_all(mysqli_query($con, $sql), MYSQLI_ASSOC);
}

function get_user_by_email(mysqli $con, string $email): array {
    $sql = 'SELECT * FROM `User`
            WHERE email = ?';
    $prepare_values = mysqli_prepare($con, $sql);

    mysqli_stmt_bind_param($prepare_values, 's', $email);
    mysqli_stmt_execute($prepare_values);

    return mysqli_fetch_assoc(mysqli_stmt_get_result($prepare_values)) ?? [];
}

function get_query_parameter(string $parameter): string {
    return $_GET[$parameter] ?? '';
}

function add_user(mysqli $con, array $data): void {
    
    $sql = 'INSERT INTO `User`(`email`, `name`, `password`, `contact`)
            VALUES
            (?, ?, ?, ?)';
    $prepare_values = mysqli_prepare($con, $sql);

    mysqli_stmt_bind_param($prepare_values, 'ssss',
        $data['email'],
        $data['name'],
        $data['password'],
        $data['message'],
    );
    mysqli_stmt_execute($prepare_values);
}

function get_lots_for_range(mysqli $con):array {
    $sql = 'SELECT l.*, cat.name AS category, cat.symbol_code AS category_code  FROM Lot as l
    LEFT JOIN Category AS cat ON cat.id = l.category_id
    WHERE l.date_end >= CURRENT_DATE()
    ORDER BY l.date_start DESC;';

    $result = mysqli_query($con, $sql);
    if (!$result) {
        $error = mysqli_error($con);
        print("Ошибка MySQL: " . $error);
        return [];
    } else {
        return mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
}

function add_lot(mysqli $con, array $data) {
    $sql = 'INSERT INTO `Lot`(`name`, `description`, `image`, `price_start`, `date_end`,
            `step`, `author_id`, `category_id`)
            VALUES
            (?, ?, ?, ?, ?, ?, ?, ?)';
    $prepare_values = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($prepare_values, 'sssisiii', 
    $data['lot-name'],
    $data['message'],
    $data['lot-img'],
    $data['lot-rate'],
    $data['lot-date'],
    $data['lot-step'],
    $data['author_id'],
    $data['category']);
    mysqli_stmt_execute($prepare_values);

    return mysqli_insert_id($con);
}

function getPostVal($name): string {
    return $_POST[$name] ?? "";
}

function validateFilled($name, $value): string {
    if (empty($_POST[$name])) {
        return $value;
    };

    return "";
}

function validateEmail(array $errors): array {
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Некорректный формат email';
    }

    return $errors;
}

function validateDropdown($name, $value): string {
   
    if (!$_POST[$name]) {
        return $value;
    };

    return "";
}

function validateImg($name, $value): string {
    if (!$name) {
        return $value;
    };

    return "";
}

function validateDate($name, $value): string {
    $time = get_dt_range($name);
    if (intval($time[0]) <= 0) {
        return $value;
    };

    return "";
}

function validateImgOnExtension(string $name, $value): string {
    $file_info = pathinfo($name);
    return in_array($file_info['extension'], IMAGE_EXTENSIONS) ? "" : $value;
}

function get_lot_by_id(mysqli $con):array {
    $id = filter_input(INPUT_GET, 'id');
    $sql = 'SELECT l.*, cat.name AS category, cat.symbol_code AS category_code,
    (SELECT `user_id` FROM `Bet` WHERE `lot_id` = '.$id.' ORDER BY `date` DESC LIMIT 1) AS `lastBetUserId`
    FROM Lot as l
    INNER JOIN Category AS cat ON cat.id = l.category_id
    WHERE l.id ='.$id;

    $result = mysqli_query($con, $sql);
    if ($result) {
         return mysqli_fetch_array($result, MYSQLI_ASSOC);   
    } else {
         print("Ошибка MySQL: " . mysqli_error($con));
         return [];
    }
}

function get_categories_for_range(mysqli $con):array {
    $sql = "SELECT * FROM  Category";
    $result = mysqli_query($con, $sql);
    if (!$result) {
        $error = mysqli_error($con);
        print("Ошибка MySQL: " . $error);
        return [];
    } else {
        return mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
}

function checkVal(string $val): string {
    return $_GET[$val] ?? '';
}

function checkId(mysqli $con): bool {
    $id = filter_input(INPUT_GET, 'id');
    $lots = get_lots_for_range($con);
    $flag = false;

    foreach ($lots as $item) {
        if ($item['id'] == $id) {
            $flag = true;
            break;
        }
    }

    return $flag;
}

function count_lots_by_query_parameter(mysqli $con, string $queryParameter): int {
    $parameterValue = get_query_parameter($queryParameter);
    if ($queryParameter === 'search') {
        $sql = 'SELECT COUNT(*) FROM `Lot`
                WHERE `date_end` >= CURRENT_DATE 
                AND MATCH(`name`, `description`) AGAINST(?)';
        

    } else if ($queryParameter === 'category') {
        $sql = 'SELECT COUNT(*) FROM `Lot` AS `L`
                INNER JOIN `Category` AS `C` ON `L`.`category_id` = `C`.`id`
                WHERE `date_end` >= CURRENT_DATE 
                AND `C`.`symbol_code` = ?';
    } else {
        return 0;
    }

    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, 's', $parameterValue);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    return mysqli_fetch_row($result)[0] ;
}

function get_lots_by_search_query(mysqli $con, int $lotsPerPage, string $searchQuery): array {
    $offset = (intval(get_query_parameter('page')) - 1) * $lotsPerPage;

    $sql = 'SELECT `L`.`id`, `L`.`name`, `price_start`, `image`, `C`.`name` AS `category_name`,
            `C`.`symbol_code` AS `category_code`, `date_start`, `date_end`
            FROM `Lot` AS `L`
            INNER JOIN `Category` AS `C` ON `L`.`category_id` = `C`.`id`
            WHERE `date_end` >= CURRENT_DATE AND MATCH(`L`.`name`, `description`) AGAINST(?)
            ORDER BY `date_start` DESC
            LIMIT ? OFFSET ?';
    $prepare_values = mysqli_prepare($con, $sql);

    mysqli_stmt_bind_param($prepare_values, 'sii', 
        $searchQuery,
        $lotsPerPage,
        $offset
    );
    mysqli_stmt_execute($prepare_values);

    return mysqli_fetch_all(mysqli_stmt_get_result($prepare_values), MYSQLI_ASSOC);
}

function get_lots_by_category(mysqli $con, int $lotsPerPage, string $categoryCode): array {
    $offset = (intval(get_query_parameter('page')) - 1) * $lotsPerPage;

    $sql = 'SELECT `L`.`id`, `L`.`name`, `price_start`, `image`, `C`.`name` AS `category_name`,
            `C`.`symbol_code` AS `category_code`, `date_start`, `date_end`
            FROM `Lot` AS `L`
            INNER JOIN `Category` AS `C` ON `L`.`category_id` = `C`.`id`
            WHERE `date_end` >= CURRENT_DATE AND `C`.`symbol_code` = ?
            ORDER BY `date_start` DESC
            LIMIT ? OFFSET ?';
    $prepare_values = mysqli_prepare($con, $sql);

    mysqli_stmt_bind_param($prepare_values, 'sii',
        $categoryCode,
        $lotsPerPage,
        $offset
    );
    mysqli_stmt_execute($prepare_values);

    return mysqli_fetch_all(mysqli_stmt_get_result($prepare_values), MYSQLI_ASSOC);
}

function get_url_for_pagination(int $page): string {
    $url = ((!empty($_SERVER['HTTPS'])) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $url = explode('?', $url);
    $url = $url[0];

    $parameters = [];
    parse_str($_SERVER['QUERY_STRING'], $parameters);

    $parameters['page'] = $page;

    return $url . "?" . http_build_query($parameters);
}

function get_bets_for_user(mysqli $con): array {
    $sql = 'SELECT `B`.`id`,`B`.`date`, `B`.`price`, `L`.`name` AS `lot_title`, `L`.`image` AS `lot_img`, 
            `L`.`id` AS `lot_id`, `L`.`date_end` AS `lot_end_date`, `L`.`winner_id` AS `lot_winner_id`, 
            `L`.`author_id` AS `lot_author_id`, `C`.`name` AS `lot_category_title`, `C`.`symbol_code` AS `lot_category_code` 
            FROM `Bet` AS `B`
            INNER JOIN `Lot` AS `L` ON `L`.`id` = `B`.`lot_id`
            INNER JOIN `Category` AS `C` ON `C`.`id` = `L`.`category_id`
            WHERE `B`.`user_id` = ?
            ORDER BY `B`.`date` DESC';

    $prepare_values = mysqli_prepare($con, $sql);

    $user_id = $_SESSION['user_id'];

    mysqli_stmt_bind_param($prepare_values, 'i',
        $user_id
    );
    mysqli_stmt_execute($prepare_values);

    return mysqli_fetch_all(mysqli_stmt_get_result($prepare_values), MYSQLI_ASSOC);
}

function get_last_user_bet_id_for_lot(mysqli $con, int $lotId): int {
    $sql = 'SELECT `id` FROM `Bet`
            WHERE `lot_id` ='.$lotId.' AND `user_id` ='.$_SESSION['user_id'].' 
            ORDER BY `price` DESC
            LIMIT 1';

    $result = mysqli_query($con, $sql);

    return mysqli_fetch_row($result)[0] ?? 0;
}

function get_user_contacts(mysqli $con, int $user_id): string {
    $sql = 'SELECT `contact` FROM `User`
            WHERE `id` ='.$user_id;

    $result = mysqli_query($con, $sql);

    return mysqli_fetch_row($result)[0] ?? "";
}

function check_lot_by_query_id(mysqli $con): bool {
    $id = filter_input(INPUT_GET, 'id');

    $sql = 'SELECT COUNT(*) FROM `Lot`
            WHERE `id` = '.$id;

    $result = mysqli_query($con, $sql);
    return mysqli_fetch_row($result)[0];
}

function get_max_bet_sum_for_lot(mysqli $con): int {
    $sql = 'SELECT `B`.`price` from `Bet` AS `B`
            WHERE `B`.`lot_id` = ?
            ORDER BY `B`.`price` DESC
            LIMIT 1';

    $prepare_values = mysqli_prepare($con, $sql);

    $lot_id = intval(get_query_parameter('id'));

    mysqli_stmt_bind_param($prepare_values, 'i',
        $lot_id
    );
    mysqli_stmt_execute($prepare_values);

    return mysqli_fetch_row(mysqli_stmt_get_result($prepare_values))[0] ?? 0;
}

function validateLotInt(array $errors, string $key): array {
    if (!filter_var($_POST[$key], FILTER_VALIDATE_INT, array('options' => array('min_range' => 0)))) {
        $errors[$key] = 'Введите целое число больше 0';
    }

    return $errors;
}

function add_bet(mysqli $con): void {
    $sql = 'INSERT INTO `Bet` (`price`, `user_id`, `lot_id`)
            VALUES (?, ?, ?)';
    $prepare_values = mysqli_prepare($con, $sql);

    $price = intval(getPostVal('cost'));
    $user_id = $_SESSION['user_id'];
    $lot_id = intval(get_query_parameter('id'));

    mysqli_stmt_bind_param($prepare_values, 'iii',
        $price,
        $user_id,
        $lot_id
    );
    mysqli_stmt_execute($prepare_values);
}

function get_bets_for_lot(mysqli $con): array {
    $sql = 'SELECT `B`.`date`, `B`.`price`, `U`.`name` AS `username` from `Bet` AS `B`
            INNER JOIN `User` AS `U` ON `U`.`id` = `B`.`user_id`
            WHERE `B`.`lot_id` = ?
            ORDER BY `B`.`price` DESC
            LIMIT 10';
    $prepare_values = mysqli_prepare($con, $sql);

    $lot_id = intval(get_query_parameter('id'));

    mysqli_stmt_bind_param($prepare_values, 'i',
        $lot_id
    );
    mysqli_stmt_execute($prepare_values);

    return mysqli_fetch_all(mysqli_stmt_get_result($prepare_values), MYSQLI_ASSOC);
}

function get_expired_lots_list(mysqli $con): array {
    $sql = 'SELECT * FROM `Lot`
            WHERE `date_end` < CURRENT_DATE';
    $result = mysqli_query($con, $sql);

    return mysqli_fetch_all($result, MYSQLI_ASSOC) ?? [];
}

function set_winner_for_lot(mysqli $con, int $lotId): void {
    $sql = 'UPDATE `Lot`
            SET `winner_id` = (SELECT `user_id` FROM `Bet` WHERE `lot_id` = '.$lotId.' ORDER BY `date` DESC LIMIT 1)
            WHERE `id` ='.$lotId;

    mysqli_query($con, $sql);
}

function get_category_name_by_query_parameter(mysqli $con): string {
    $sql = 'SELECT `name` FROM `Category`
            WHERE `symbol_code` = ?';

    $prepare_values = mysqli_prepare($con, $sql);
    $queryParameter = get_query_parameter('category');

    mysqli_stmt_bind_param($prepare_values, 's',
        $queryParameter
    );
    mysqli_stmt_execute($prepare_values);

    $result = mysqli_fetch_row(mysqli_stmt_get_result($prepare_values));
    return $result[0] ?? '';
}
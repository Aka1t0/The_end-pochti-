<?php
require_once('init.php');
require_once('helpers.php');
require_once('functions.php');


$nav = include_template("nav.php", [
    "promos" => get_categories_for_range($con),
]);

$errors = [];
if (!isset($_SESSION['username'])) {
    http_response_code(403);

    $errorPage = include_template('403.php', [
        "nav" => $nav,
    ]);

    $layout = include_template("layout.php", [
        "content" => $errorPage,
        "promos" => get_categories_for_range($con),
        "title" => "Доступ запрещён",
    ]);
} else {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $required_fields = [
        'lot-name' => 'Введите наименование лота', 
        'category' => 'Выберите категорию', 
        'message' => 'Напишите описание лота', 
        'lot-rate' => 'Введите начальную цену', 
        'lot-step' => 'Введите шаг ставки', 
        'lot-date' => 'Введите дату завершения торгов',
    ];
    $errors = [];

   
    foreach($_POST as $key => $value) {
        if (isset($required_fields[$key])) {
            switch($key){
                case 'category':  
                    $error = $required_fields[$key];
                    $errors[$key] = validateDropdown($key, $required_fields[$key]);
                    break;
                default:
                    $error = $required_fields[$key];
                    $errors[$key] = validateFilled($key, $required_fields[$key]);
            }
        }
    }

    $errors['lot-img'] = validateImg($_FILES['lot-img']['name'], 'Загрузите изображение лота');

    if(!$errors['lot-img']) {
        $errors['lot-img'] = validateImgOnExtension($_FILES['lot-img']['name'], 'Неверный формат изображения');
    } 

    if(!$errors['lot-rate'] && (!ctype_digit($_POST['lot-rate']))) {
        $errors['lot-rate'] = 'Цена должна быть целым числом';
    } else if (($_POST['lot-rate']) < 0){
        $errors['lot-rate'] = 'Цена не может быть отрицательным числом';
    } else if (substr($_POST['lot-rate'], 0, 1) == 0) {
        $errors['lot-rate'] = 'Введите цену';
    }

    if(!$errors['lot-step'] && (!ctype_digit($_POST['lot-step']))) {
        $errors['lot-step'] = 'Шаг ставки должен быть целым числом';
    } else if (($_POST['lot-step']) < 0){
        $errors['lot-step'] = 'Шаг ставки не может быть отрицательным числом';
    } else if (substr($_POST['lot-step'], 0, 1) == 0) {
        $errors['lot-step'] = 'Введите шаг ставки';
    }
    $validateDate = validateDate($_POST['lot-date'], 'Введенная дата уже прошла');
    if(!$errors['lot-date'] && !is_date_valid($_POST['lot-date'])) {
        $errors['lot-date'] = 'Неверный формат даты';
    } else if ($validateDate) {
        $errors['lot-date'] = $validateDate;
    }
    $errors = array_filter($errors);

    if(!$errors){
        $file_name = strval(time()).$_FILES['lot-img']['name'];
        $file_path = __DIR__.'/uploads/';
        $file_url = '/uploads/' . $file_name;
        
        move_uploaded_file($_FILES['lot-img']['tmp_name'], $file_path . $file_name);
        $data = $_POST;
        $data['author_id'] = $_SESSION['user_id'];
        $data['lot-img'] = $file_url;
        $id = add_lot($con, $data);

        header('Location: /lot.php?id=' . $id);    
    }
    }
    $add = include_template("add_lot.php", [
        "categories" => get_categories_for_range($con),
        "nav" => $nav,
        'errors' => $errors,
    ]);
    
    $layout = include_template("layout.php", [
        "content" => $add,
        "promos" => get_categories_for_range($con),
        "title" => "Новый лот",
    ]);
}
    
print($layout);
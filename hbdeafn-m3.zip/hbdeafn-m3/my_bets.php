<?php
require_once('init.php');
require_once('helpers.php');
require_once('functions.php');

$promos = get_categories_for_range($con);
$nav = include_template("nav.php", [
     "promos" => $promos,
]);

$header = include_template('header.php',[
    'categories' => get_categories_for_range($con),
]);

$footer = include_template('footer.php', [
    'categories' => get_categories_for_range($con),
]);

$userBets = get_bets_for_user($con);

$bets = include_template('my_bets.php', [
    'promos' => $promos,
    'nav' => $nav,
    'userBets' => $userBets,
    'con' => $con,
]);

$layout = include_template('layout.php', [
    'title' => 'Мои ставки',
    "content" => $bets,
    "promos" => $promos,
]);

print($layout);
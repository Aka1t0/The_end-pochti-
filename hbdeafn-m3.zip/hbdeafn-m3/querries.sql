INSERT INTO Category (id, name, symbol_code) VALUES
    (1, 'Доски и лыжи', 'boards'),
    (2, 'Крепления', 'attachment'),
    (3, 'Ботинки', 'boots'),
    (4, 'Одежда', 'clothing'),
    (5, 'Инструменты', 'tools'),
    (6, 'Разное', 'other');

INSERT INTO User (id, date_registration, email, name, password, contact) VALUES
    (1, '2014-05-25', 'vagan@mail.ru', 'Жорик', 'jora', '+71947294341'),
    (2, '2013-02-28', 'dimaurg@gmail.com', 'Дорик', 'dora', '+71947644341'),
    (3, '2020-06-30', 'opapopa@mail.ru', 'Ворик', 'vora', '+71434791241');


INSERT INTO Lot (id, date_start, name, description, image, price_start, date_end, author_id, winner_id, category_id, step) VALUES
    (1, '2023-05-25', '2014  Rossignol District Snowboard', '2014  Rossignol District Snowboard', 'img/lot-1.jpg', 10999,  '2023-09-14', 1, 2, 1, 500),
    (2, '2023-07-25', 'DC Ply Mens 2016/2017 Snowboard', 'DC Ply Mens 2016/2017 Snowboard',  'img/lot-2.jpg', 159999, '2023-09-13 10:20', 1, 3, 1, 1000),
    (3, '2023-09-14', 'Крепления Union Contact Pro 2015 года размер L/XL', 'Крепления Union Contact Pro 2015 года размер L/XL', 'img/lot-3.jpg', 8000, '2023-09-16', 2, 1, 2, 500),
    (4, '2023-09-13', 'Ботинки для сноуборда DC Mutiny Charocal', 'Ботинки для сноуборда DC Mutiny Charocal', 'img/lot-4.jpg', 10999, '2023-09-16', 2, 3, 3, 500),
    (5, '2023-09-11', 'Куртка для сноуборда DC Mutiny Charocal', 'Куртка для сноуборда DC Mutiny Charocal', 'img/lot-5.jpg', 7500, '2023-09-25', 3, 1, 4, 500),
    (6, '2023-09-10', 'Маска Oakley Canopy', 'Маска Oakley Canopy', 'img/lot-6.jpg', 5400, '2023-09-30', 3, 2, 6, 100);

INSERT INTO Bet (id, date, price, user_id, lot_id) VALUES
    (1, '2023-05-31 17:00', 11999, 2, 1),
    (2, '2023-07-30 16:00', 160999, 2, 3),
    (3, '2023-07-30 17:35', 161999, 3, 3);

/*First task*/
SELECT * FROM Category;
/*Second task*/
SELECT l.name, l.price_start, l.image, cat.name, l.date_end FROM Lot as l
    LEFT JOIN Category AS cat ON cat.id = l.category_id
    WHERE l.date_end > CURRENT_DATE()
    ORDER BY l.date_start DESC;
/*Third task*/
SELECT l.*, cat.name AS category_name FROM Lot AS l
   LEFT JOIN Category AS cat ON cat.id = l.category_id
   WHERE l.id = 2;
/*Fourth task*/
UPDATE Lot
SET name='Доска гладильная'
WHERE id=1;
/*Fifth task*/
SELECT b.date, b.price, u.name, l.name FROM Bet AS b
    LEFT JOIN User AS u ON u.id = b.user_id
    LEFT JOIN Lot AS l ON l.id = b.lot_id
    WHERE b.lot_id = 2
    ORDER BY b.date;
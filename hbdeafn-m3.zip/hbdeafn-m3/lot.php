<?php
require_once('init.php');
require_once('helpers.php');
require_once('functions.php');

$promos = get_categories_for_range($con);
$nav = include_template("nav.php", [
    "promos" => $promos,
]);

if (!get_query_parameter('id') || !check_lot_by_query_id($con)) {
    http_response_code(404);

    $notFound = include_template('404.php', [
        'nav' => $nav,
    ]);
    $layout = include_template('layout.php',[
        'title' => 'Страница не найдена',
        'content' => $notFound,
        'promos' => $promos,
    ]);
} else {
    $lot = get_lot_by_id($con);
    $maxBetSum = get_max_bet_sum_for_lot($con);

    if ($maxBetSum === 0) {
        $minBet = $lot['price_start'] + $lot['step'];
        $currentPrice = $lot['price_start'];
    } else {
        $minBet = $maxBetSum + $lot['step'];
        $currentPrice = $maxBetSum;
    }

    $errors = [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $bet = getPostVal('cost');

        if (empty($bet)) {
            $errors['cost'] = 'Введите вашу ставку';
        }
        if (empty($errors)) {
            $errors = validateLotInt($errors, 'cost');
        }
        if (empty($errors) && intval($bet) < $minBet) {
            $errors['cost'] = 'Ставка меньше минимальной';
        }

        $errors = array_filter($errors);
        if (!$errors) {
            add_bet($con);
            header('Location: ../lot.php?id='.$lot['id']);
        }
    }
    $bets = get_bets_for_lot($con);
    
    $lot = include_template("lot.php", [
        'lot' => $lot,
        "bets" => $bets,
        'currentPrice' => $currentPrice,
        'minBet' => $minBet,
        'errors' => $errors,
        'nav' => $nav,
    ]);

    $layout = include_template('layout.php', [
        'title' => 'О лоте',
        'content' => $lot,
        'promos' => $promos,
    ]);
}
 
// $layout = include_template('layout.php', [
//     'title' => 'О лоте',
//     'content' => $lot,
//     'promos' => $promos,
// ]);


print($layout);
<?php
require_once('helpers.php');
require_once('functions.php');
require_once('init.php');
$promos = get_categories_for_range($con);
$lots = get_lots_for_range($con);

$main = include_template('main.php', [
        'promos' => $promos,
        'lots' => $lots,
]);

$layout = include_template('layout.php', [
        'title' => 'Главная',
        'content' => $main,
        'promos' => $promos,
]);

$expiredLots = get_expired_lots_list($con);
foreach ($expiredLots as $lot) {
        set_winner_for_lot($con, $lot['id']);
}
print($layout);
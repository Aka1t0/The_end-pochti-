<?php
require_once('init.php');
require_once('helpers.php');
require_once('functions.php');
$promos = get_categories_for_range($con);
$nav = include_template("nav.php", [
     "promos" => $promos,
]);

$errors = [];
$required_fields = [
    'email' => 'Введите email',
    'password' => 'Введите пароль',
    'name' => 'Введите имя',
    'message' => 'Напишите ваши контактные данные'
];

if (isset($_SESSION['username'])) {
    http_response_code(403);

    $registration_content = include_template('403.php', [
        'nav' => $nav,
    ]);

    print(include_template('layout.php', [
        'title' => 'Доступ запрещен',
        "content" => $registration_content,
        "promos" => $promos,
        "is_auth" => $is_auth,
        
        "user_name" => $user_name,
        "nav" => $nav,
    ]));
} else {
    $errors = [];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        foreach($required_fields as $key => $value) {
            if (empty($_POST[$key])) {
                $errors[$key] = $value;
            }
        }

        if (!isset($errors['email'])) {
            $errors = validateEmail($errors);
        }

        if (!isset($errors['email']) && !empty(get_user_by_email($con, $_POST['email']))) {
            $errors['email'] = 'E-mail уже используется';
        }

        $errors = array_filter($errors);

        if(!$errors){
            $passwordHash = password_hash($_POST['password'], PASSWORD_DEFAULT);

            $data = $_POST;
            $data['password'] = $passwordHash;
            add_user($con, $data);

            header('Location: /login.php');
            exit;
        }
    }
}
$signup = include_template('sign_up.php', [
    'promos' => $promos,
    'nav' => $nav,
    'errors' => $errors,  
]);

$layout = include_template('layout.php', [
    'title' => 'Регистрация',
    "content" => $signup,
    "promos" => $promos,
    "nav" => $nav,
]);

print($layout);



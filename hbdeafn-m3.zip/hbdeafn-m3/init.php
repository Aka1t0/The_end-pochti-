<?php

session_start();
const HOST = 'localhost';
const LOGIN = 'fbbfbutg';
const PASSWORD = 'ALBfLX';
const DATABASE = 'fbbfbutg_m3';

$con = mysqli_connect(HOST, LOGIN, PASSWORD, DATABASE);

mysqli_set_charset($con, "utf8");
if ($con == false) {
    print("Ошибка подключения: " . mysqli_connect_error());
}

<nav class="nav">
  <ul class="nav__list container">
    <?=$nav?>
  </ul>
</nav>
<div class="container">
  <section class="lots">
    <?php if(!$lots): ?>
        <h2>Ничего не найдено по вашему запросу</h2>
    <?php else: ?>
        <h2>Все результаты в категории «<span><?=get_category_name_by_query_parameter($con) ?></span>»</h2>
        <?= $lotsListContent ?>
    <?php endif ?>
  </section>
    <?= $paginationContent ?>
</div>
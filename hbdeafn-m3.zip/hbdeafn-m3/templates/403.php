<nav class="nav">
  <ul class="nav__list container">
    <?=$nav?>
  </ul>
</nav>
<section class="lot-item container">
<h2>403 Недостаточно прав доступа</h2>
<p>У вас нет прав доступа к данной странице, попробуйте авторизоваться</p>
</section>
<nav class="nav">
  <ul class="nav__list container">
    <?=$nav?>
  </ul>
</nav>
<div class="container">
  <section class="lots">
    <?php if(!$lots): ?>
        <h2>Ничего не найдено по вашему запросу</h2>
    <?php else: ?>
        <h2>Результаты поиска по запросу «<span><?= $queryParameterValue ?></span>»</h2>
        <?= $lotsListContent ?>
    <?php endif ?>
  </section>
    <?= $paginationContent ?>
</div>
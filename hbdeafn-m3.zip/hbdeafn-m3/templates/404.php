<nav class="nav">
  <ul class="nav__list container">
    <?=$nav?>
  </ul>
</nav>
<section class="lot-item container">
    <h2>404 Страница не найдена</h2>
    <p>Данной страницы не существует на сайте.</p>
</section>
<?php foreach($promos as $item):?>
       <li class="nav__item <?php if ($item['symbol_code'] === get_query_parameter('category')):?>nav__item--current<?php endif; ?>">
           <a href="../all_lots.php<?="?category="."{$item['symbol_code']}"?>"><?=htmlspecialchars($item['name'])?></a>
       </li>
<?php endforeach; ?>

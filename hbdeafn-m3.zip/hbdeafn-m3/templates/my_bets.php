<nav class="nav">
      <ul class="nav__list container">
        <?=$nav?>
      </ul>
    </nav>
<section class="rates container">
    <h2>Мои ставки</h2>
    <?php if(empty($userBets)):?>
    <h2>Вы еще не сделали ни одной ставки</h2>
    <?php else:?>
    <table class="rates__list">
        <?php foreach($userBets as $bet): ?>
        <?php
        $time = get_dt_range($bet['lot_end_date']);
        $itemClass = 'rates__item';
        $timerClass = 'timer';
        $isWinner = intval($_SESSION['user_id']) === $bet['lot_winner_id'];
        $timerText = "{$time[0]}:{$time[1]}";
        if(intval($time[0]) < 0) {
            if($isWinner && get_last_user_bet_id_for_lot($con, $bet['lot_id']) === $bet['id']) {
                $itemClass .= ' rates__item--win';
                $timerClass .= ' timer--win';
                $timerText = 'Ставка выиграла';
            } else {
                $itemClass .= ' rates__item--end';
                $timerClass .= ' timer--end';
                $timerText = 'Торги окончены';
            }
        } else if(intval($time[0]) < 24) {
            $timerClass .= ' timer--finishing';
        }
        ?>
        <tr class="<?= $itemClass ?>">
            <td class="rates__info">
                <div class="rates__img">
                    <img src="<?=$bet['lot_img']?>" width="54" height="40" alt="<?=$bet['lot_category_code']?>">
                </div>
                <?php if($isWinner): ?>
                <div>
                    <h3 class="rates__title"><a href="../lot.php?id=<?=$bet['lot_id']?>"><?=$bet['lot_title']?></a></h3>
                    <p><?=get_user_contacts($con, $bet['lot_author_id'])?></p>
                </div>
                <?php else: ?>
                <h3 class="rates__title"><a href="../lot.php?id=<?=$bet['lot_id']?>"><?=$bet['lot_title']?></a></h3>
                <?php endif; ?>
            </td>
            <td class="rates__category">
                <?=$bet['lot_category_title']?>
            </td>
            <td class="rates__timer">
                <div class="<?= $timerClass ?>">
                    <?=$timerText?>
                </div>
            </td>
            <td class="rates__price">
                <?=format($bet['price'])?>
            </td>
            <td class="rates__time">
                <?=formatDate($bet['date'])?>
            </td>
        </tr>
        <?php endforeach;?>
    </table>
    <?php endif; ?>
</section>
CREATE TABLE Category
(
    id          INT PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(25) NOT NULL UNIQUE,
    symbol_code VARCHAR(25) NOT NULL UNIQUE
);

CREATE TABLE User
(
    id                INT PRIMARY KEY AUTO_INCREMENT,
    date_registration TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    email             VARCHAR(25) UNIQUE,
    name              VARCHAR(25),
    password          VARCHAR(50),
    contact           VARCHAR(255) UNIQUE
);

 CREATE TABLE Lot
 (
     id          INT PRIMARY KEY AUTO_INCREMENT,
     date_start  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
     name        VARCHAR(25)  NOT NULL,
     description VARCHAR(150) NOT NULL,
     image       VARCHAR(255) NOT NULL UNIQUE,
     price_start VARCHAR(20)  NOT NULL,
     step        VARCHAR(20)  NOT NULL,
     date_end    DATE NOT NULL,
     author_id   INT NOT NULL,
     winner_id   INT,
     category_id INT NOT NULL,
     FOREIGN KEY (category_id) REFERENCES Category(id),
     FOREIGN KEY (winner_id) REFERENCES User(id),
     FOREIGN KEY (author_id) REFERENCES User(id)
 );

 CREATE TABLE Bet (
     id      INT PRIMARY KEY AUTO_INCREMENT,
     date    TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
     price   VARCHAR(20) NOT NULL,
     user_id INT         NOT NULL,
     lot_id  INT         NOT NULL,
     FOREIGN KEY (lot_id) REFERENCES Lot (id),
     FOREIGN KEY (user_id) REFERENCES User (id)
 );
<?php
require_once('init.php');
require_once('helpers.php');
require_once('functions.php');

CONST LOTS_PER_PAGE = 3;

$currentPage = 1;

$queryParameterValue = get_query_parameter('search');

if (!$queryParameterValue) {
    header('Location: /index.php');
    exit;
}

$data = $_GET;

isset($data['page']) ? $currentPage = htmlspecialchars($data['page']) : $data['page'] = 1;

if ($data['page'] === 1) {
    $scriptname = pathinfo(__FILE__, PATHINFO_BASENAME);
    $query = http_build_query($data);
    $url = "/" . $scriptname . "?" . $query;
    header("Location: ". $url);
    exit;
}

$totalLots = count_lots_by_query_parameter($con, 'search');
$totalPages = ceil($totalLots / LOTS_PER_PAGE);
$totalPages = $totalPages > 0 ? $totalPages : 1;

$categories = get_categories_for_range($con);
$nav = include_template("nav.php", [
    "promos" => $categories,
]);

if($_GET['page'] < 1 || $_GET['page'] > $totalPages) {
    http_response_code(404);
    $notFounds = include_template('404.php', ['nav' => $nav,]);
    $layot = include_template('layout.php',[
        'title' => 'Результаты поиска',
        'content' => $notFounds,
        "promos" => $categories,
        "nav" => $nav,
    ]);
} else {
    $lots = get_lots_by_search_query($con, LOTS_PER_PAGE, $queryParameterValue);

    $paginationContent = include_template('pagination.php', [
        'totalPages' => $totalPages,
        'currentPage' => $currentPage,
    ]);

    $lotsListContent = include_template('lots_list.php', [
        'lots' => $lots,
    ]);

    $search = include_template('search.php', [
        'nav' => $nav,
        'lots' => $lots,
        'queryParameterValue' => $queryParameterValue,
        'lotsListContent' => $lotsListContent,
        'paginationContent' => $paginationContent,
    ]);
  
    $layout = include_template('layout.php', [
        'title' => 'Результаты поиска',
        "content" => $search,
        "promos" => $categories,
    ]);
}

print($layout);
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 17 2023 г., 05:55
-- Версия сервера: 8.0.30
-- Версия PHP: 8.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `fbbfbutg_m3`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Bet`
--

CREATE TABLE `Bet` (
  `id` int NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `price` varchar(20) NOT NULL,
  `user_id` int NOT NULL,
  `lot_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Bet`
--

INSERT INTO `Bet` (`id`, `date`, `price`, `user_id`, `lot_id`) VALUES
(1, '2023-05-31 14:00:00', '11999', 9, 1),
(2, '2023-07-30 13:00:00', '160999', 9, 2),
(3, '2023-07-30 14:35:00', '161999', 10, 3),
(4, '2023-11-17 01:23:25', '210', 9, 16),
(5, '2023-11-17 01:28:05', '216', 10, 16),
(6, '2023-11-17 01:30:20', '250', 9, 16),
(7, '2023-11-17 01:52:43', '80000', 10, 15);

-- --------------------------------------------------------

--
-- Структура таблицы `Category`
--

CREATE TABLE `Category` (
  `id` int NOT NULL,
  `name` varchar(25) NOT NULL,
  `symbol_code` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Category`
--

INSERT INTO `Category` (`id`, `name`, `symbol_code`) VALUES
(1, 'Доски и лыжи', 'boards'),
(2, 'Крепления', 'attachment'),
(3, 'Ботинки', 'boots'),
(4, 'Одежда', 'clothing'),
(5, 'Инструменты', 'tools'),
(6, 'Разное', 'other');

-- --------------------------------------------------------

--
-- Структура таблицы `Lot`
--

CREATE TABLE `Lot` (
  `id` int NOT NULL,
  `date_start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `image` varchar(255) NOT NULL,
  `price_start` varchar(20) NOT NULL,
  `step` varchar(20) NOT NULL,
  `date_end` date NOT NULL,
  `author_id` int NOT NULL,
  `winner_id` int DEFAULT NULL,
  `category_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Lot`
--

INSERT INTO `Lot` (`id`, `date_start`, `name`, `description`, `image`, `price_start`, `step`, `date_end`, `author_id`, `winner_id`, `category_id`) VALUES
(1, '2023-05-24 21:00:00', 'Доска гладильная', '2014  Rossignol District Snowboard', 'img/lot-1.jpg', '10999', '500', '2023-11-19', 1, 9, 1),
(2, '2023-07-24 21:00:00', 'DC Ply Mens 2016/2017 Sno', 'DC Ply Mens 2016/2017 Snowboard', 'img/lot-2.jpg', '159999', '1000', '2023-11-17', 1, 9, 1),
(3, '2023-09-13 21:00:00', 'Крепления Union Contact P', 'Крепления Union Contact Pro 2015 года размер L/XL', 'img/lot-3.jpg', '8000', '500', '2023-11-16', 9, 10, 2),
(4, '2023-09-12 21:00:00', 'Ботинки для сноуборда DC ', 'Ботинки для сноуборда DC Mutiny Charocal', 'img/lot-4.jpg', '10999', '500', '2023-11-18', 2, NULL, 3),
(5, '2023-09-10 21:00:00', 'Куртка для сноуборда DC M', 'Куртка для сноуборда DC Mutiny Charocal', 'img/lot-5.jpg', '7500', '500', '2023-11-25', 10, 1, 4),
(6, '2023-09-09 21:00:00', 'Маска Oakley Canopy', 'Маска Oakley Canopy', 'img/lot-6.jpg', '5400', '100', '2023-11-30', 10, 9, 6),
(11, '2023-11-16 22:50:38', 'Очки', 'Позволяют видеть', '/uploads/1700175038anime-landscape-cool-structures-sxav7vm5ynwkn8p7.jpg', '2000', '100', '2023-11-23', 7, NULL, 6),
(12, '2023-11-16 22:52:23', 'Сбитый спутник МКС', 'Когда был связующим звеном между странами, но теперь он упал', '/uploads/1700175143shooting-stars-anime-landscape-ht1plhm7bw1vl46n.jpg', '100500', '500', '2023-11-23', 7, NULL, 6),
(13, '2023-11-16 23:15:47', 'Гитара', 'Чуть чуть б/у, но если склеить перемотать скотчем и не играть то збс', '/uploads/1700176547wallpaperflare.com_wallpaper (37).jpg', '4000', '500', '2023-11-22', 7, NULL, 6),
(14, '2023-11-16 23:48:00', 'Бас-гитара', 'Продается по неслыханной цене', '/uploads/1700178480wallpaperflare.com_wallpaper (39).jpg', '1000', '20', '2023-11-26', 7, NULL, 6),
(15, '2023-11-16 23:50:45', 'Шкет с гитарой', 'Выступит на любом вашем корпоративе. Гитара своя', '/uploads/1700178645wallpaperflare.com_wallpaper (47).jpg', '7500', '500', '2023-11-21', 7, NULL, 6),
(16, '2023-11-17 00:02:55', 'Картинка из интернета', 'Картинка из интернета, на которой изображена гитара', '/uploads/1700179375wallpaperflare.com_wallpaper (36).jpg', '200', '5', '2023-11-16', 7, 9, 5),
(18, '2023-11-17 02:45:51', 'Крепления для сноуборда ARBOR CYPRESS', 'Жесткие крепления, подходящие для фри-райда в желтой расцветке', '/uploads/1700189151изображение_2023-11-17_074540535.png', '25780', '999', '2023-11-19', 10, NULL, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `User`
--

CREATE TABLE `User` (
  `id` int NOT NULL,
  `date_registration` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(25) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `User`
--

INSERT INTO `User` (`id`, `date_registration`, `email`, `name`, `password`, `contact`) VALUES
(1, '2014-05-24 21:00:00', 'vagan@mail.ru', 'Жорик', '$2y$10$YDysvO2aqpgm4WMJKTUqfuEpXplJKUadVqvc9GnwnSbsiBSwh3zUS', '+71947294341'),
(2, '2013-02-27 21:00:00', 'dimaurg@gmail.com', 'Дорик', '$2y$10$YDysvO2aqpgm4WMJKTUqfuEpXplJKUadVqvc9GnwnSbsiBSwh3zUS', '+71947644341'),
(3, '2020-06-29 21:00:00', 'opapopa@mail.ru', 'Ворик', '$2y$10$YDysvO2aqpgm4WMJKTUqfuEpXplJKUadVqvc9GnwnSbsiBSwh3zUS', '+71434791241'),
(7, '2023-11-15 18:51:51', 'owo@owo.owo', 'owo', '$2y$10$YDysvO2aqpgm4WMJKTUqfuEpXplJKUadVqvc9GnwnSbsiBSwh3zUS', 'owo'),
(9, '2023-11-17 01:20:27', 'jora@mail.ru', 'Жорик', '$2y$10$au3dzurDTz65vbkDSeLj1O2RcPwUNWeXI.bMrePMZulYEi3OQ77dC', '8 800 555 35 35'),
(10, '2023-11-17 01:27:31', 'danchik@gmail.com', 'Дэн4ик', '$2y$10$btM2CNz9jMfYNMgQ/vZdaOoyW7/GxH3yPBGVJjrAA6z10U966s8vO', 'Я слазаю, мне не до данных');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Bet`
--
ALTER TABLE `Bet`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lot_id` (`lot_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `symbol_code` (`symbol_code`);
ALTER TABLE `Category` ADD FULLTEXT KEY `symbol_code_2` (`symbol_code`);

--
-- Индексы таблицы `Lot`
--
ALTER TABLE `Lot`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `image` (`image`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `winner_id` (`winner_id`),
  ADD KEY `author_id` (`author_id`);
ALTER TABLE `Lot` ADD FULLTEXT KEY `name` (`name`);
ALTER TABLE `Lot` ADD FULLTEXT KEY `description` (`description`);
ALTER TABLE `Lot` ADD FULLTEXT KEY `description_2` (`description`);
ALTER TABLE `Lot` ADD FULLTEXT KEY `name_2` (`name`);
ALTER TABLE `Lot` ADD FULLTEXT KEY `name_3` (`name`,`description`);

--
-- Индексы таблицы `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `contact` (`contact`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Bet`
--
ALTER TABLE `Bet`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `Category`
--
ALTER TABLE `Category`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `Lot`
--
ALTER TABLE `Lot`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `User`
--
ALTER TABLE `User`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `Bet`
--
ALTER TABLE `Bet`
  ADD CONSTRAINT `bet_ibfk_1` FOREIGN KEY (`lot_id`) REFERENCES `Lot` (`id`),
  ADD CONSTRAINT `bet_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `User` (`id`);

--
-- Ограничения внешнего ключа таблицы `Lot`
--
ALTER TABLE `Lot`
  ADD CONSTRAINT `lot_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `Category` (`id`),
  ADD CONSTRAINT `lot_ibfk_2` FOREIGN KEY (`winner_id`) REFERENCES `User` (`id`),
  ADD CONSTRAINT `lot_ibfk_3` FOREIGN KEY (`author_id`) REFERENCES `User` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
